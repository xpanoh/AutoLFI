import aiohttp
import asyncio
from tqdm import tqdm
from typing import List
import aiofiles
from collections import Counter
import time

# Custom HTTP timeout settings
TIMEOUT = aiohttp.ClientTimeout(total=30)

# Default headers to mimic ffuf's behavior
HEADERS = {
    "User-Agent": "ffuf/v2.1.0-dev",
    "Accept": "*/*",
    "Accept-Language": "en-US,en;q=0.5",
    "Connection": "keep-alive",
    "Accept-Encoding": "identity",  # Disable compression
}

async def load_wordlist(filename: str) -> List[str]:
    """Load a wordlist file and return non-empty lines."""
    async with aiofiles.open(filename, mode='r') as file:
        lines = await file.readlines()
        return [line.strip() for line in lines if line.strip()]

async def fetch(session, url):
    """Fetch a URL and return the status code, response size, and response time."""
    start_time = time.time()
    try:
        async with session.get(url) as response:
            content = await response.read()
            response_size = len(content)  # Use only the body size
            response_time = time.time() - start_time
            return response.status, response_size, response_time
    except asyncio.CancelledError:
        print(f"[-] Request cancelled for {url}, retrying...")
        return None, None, None
    except aiohttp.ClientError:
        return None, None, None

async def find_mode_bruteforce(base_url: str, wordlist: List[str], extension: str, concurrency: int):
    """Brute-force URLs using a wordlist and replace FIND with wordlist entries."""
    ALLOWED_STATUS_CODES = {200, 201, 202, 203, 204, 205, 206, 207, 208, 226,
                            301, 302, 307,
                            401, 403, 405,
                            500}
    async with aiohttp.ClientSession(headers=HEADERS, timeout=TIMEOUT) as session:
        semaphore = asyncio.Semaphore(concurrency)
        async with aiofiles.open('Fuzz_results.txt', mode='w') as out_file:
            async def process_candidate(candidate: str):
                async with semaphore:
                    full_url = base_url.replace("FIND", candidate) + extension
                    status, size, response_time = await fetch(session, full_url)
                    if status in ALLOWED_STATUS_CODES:
                        tqdm.write(f"{candidate.ljust(20)} [Status: {status}, Time: {response_time:.2f}s]")
                        await out_file.write(f"{full_url}\n")
                    # Adjust concurrency based on response time
                    if response_time and response_time > 2.0:  # If response time is more than 2 seconds
                        await asyncio.sleep(1)  # Add a delay to slow down the rate

            tasks = [process_candidate(candidate) for candidate in wordlist]
            for task in tqdm(asyncio.as_completed(tasks), total=len(tasks), desc="Processing wordlist"):
                await task

    print("[+] Brute-force scanning complete.")

async def fuzz_get_parameters(urls_file: str, parameter_wordlist: List[str], concurrency: int):
    """Fuzz for GET parameters by appending ?FUZZ=key to URLs."""
    ALLOWED_STATUS_CODES = {200, 301, 302, 403}  # Adjust based on expected behavior
    async with aiohttp.ClientSession(headers=HEADERS, timeout=TIMEOUT) as session:
        semaphore = asyncio.Semaphore(concurrency)
        async with aiofiles.open('Fuzz_GETResults.txt', mode='w') as out_file:
            # Load URLs from results.txt
            async with aiofiles.open(urls_file, mode='r') as file:
                urls = [line.strip() for line in await file.readlines() if line.strip()]

            # Step 1: Detect the most common response size using the first 5 parameters
            async def get_baseline_response_size(url: str, initial_parameters: List[str]):
                response_sizes = []
                for param in tqdm(initial_parameters, desc=f"Calculating baseline for {url}", leave=False):
                    fuzzed_url = f"{url}?{param}=key"
                    status, response_size, response_time = await fetch(session, fuzzed_url)
                    if response_size is not None:
                        response_sizes.append(response_size)

                # Find the most common response size
                size_counts = Counter(response_sizes)
                baseline_size = size_counts.most_common(1)[0][0] if size_counts else None
                tqdm.write(f"[+] Baseline response size for {url}: {baseline_size}")
                return baseline_size

            # Step 2: Process all combinations of URLs and parameters
            async def process_url_and_parameter(url: str, parameter: str, baseline_size: int):
                async with semaphore:
                    fuzzed_url = f"{url}?{parameter}=key"
                    status, response_size, response_time = await fetch(session, fuzzed_url)
                    if status in ALLOWED_STATUS_CODES and response_size != baseline_size:
                        tqdm.write(f"{fuzzed_url.ljust(60)} [Status: {status}, Size: {response_size}, Time: {response_time:.2f}s]")
                        await out_file.write(f"{fuzzed_url}\n")
                    # Adaptive rate limiting
                    if response_time and response_time > 2.0:  # If response time is more than 2 seconds
                        await asyncio.sleep(1)  # Add a delay to slow down the rate

            # Main processing loop
            for url in urls:
                print(f"\n[+] Processing URL: {url}")

                # Step 1: Calculate baseline response size for this URL
                baseline_size = await get_baseline_response_size(url, parameter_wordlist[:5])
                if baseline_size is None:
                    tqdm.write(f"[-] Skipping URL {url} due to lack of baseline response size.")
                    continue

                # Step 2: Fuzz the full wordlist for this URL
                tasks = [process_url_and_parameter(url, param, baseline_size) for param in parameter_wordlist]
                for task in tqdm(asyncio.as_completed(tasks), total=len(tasks), desc=f"Fuzzing GET parameters for {url}"):
                    await task

        print("[+] GET parameter fuzzing complete.")