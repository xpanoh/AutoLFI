#main.py
import asyncio
from fuzzing import find_mode_bruteforce, load_wordlist, fuzz_get_parameters
from reading import test_lfi, fetch_webpage_source
from rce import rce_expect, rce_data, rce_post, rce_log_poisoning
from rfi import rfi_main

BANNER = """ 
 █████╗ ██╗   ██╗████████╗ ██████╗ ██╗     ███████╗██╗
██╔══██╗██║   ██║╚══██╔══╝██╔═══██╗██║     ██╔════╝██║
███████║██║   ██║   ██║   ██║   ██║██║     █████╗  ██║
██╔══██║██║   ██║   ██║   ██║   ██║██║     ██╔══╝  ██║
██║  ██║╚██████╔╝   ██║   ╚██████╔╝███████╗██║     ██║
╚═╝  ╚═╝ ╚═════╝    ╚═╝    ╚═════╝ ╚══════╝╚═╝     ╚═╝
         Automated LFI Security Testing Toolkit
""" 
async def main():
    print(BANNER)

    while True:
        print("\n=== Tool Menu ===")
        print("1. Fuzzing")
        print("2. Reading")
        print("3. RCE")
        print("4. RFI")
        print("5. Exit")
        choice = input("Enter your choice: ")
        if choice == "1":
            # Fuzzing Sub-menu
            print("\n=== Fuzzing Options ===")
            print("a. Fuzz for pages")
            print("b. Fuzz for GET parameters")
            sub_choice = input("Enter your choice (a/b): ")
            if sub_choice == "a":
                # Fuzz for pages
                base_url = input("Enter the target URL with FIND placeholder (e.g., http://testphp.vulnweb.com/FIND): ")
                wordlist_file = input("Enter the wordlist file path: ")
                extension = input("Enter the file extension to append (e.g., .php): ")
                concurrency = int(input("Enter the number of concurrent workers: "))
                wordlist = await load_wordlist(wordlist_file)
                await find_mode_bruteforce(base_url, wordlist, extension, concurrency)
            elif sub_choice == "b":
                # Fuzz for GET parameters
                parameter_wordlist_file = input("Enter the parameter wordlist file path (e.g., ./burp-parameter-names): ")
                concurrency = int(input("Enter the number of concurrent workers: "))
                parameter_wordlist = await load_wordlist(parameter_wordlist_file)
                await fuzz_get_parameters("Fuzz_results.txt", parameter_wordlist, concurrency)
            else:
                print("[-] Invalid choice.")
        elif choice == "2":
            # Reading Sub-menu
            print("\n=== Reading Options ===")
            print("a. Read files on the system")
            print("b. Read source code of a webpage")
            sub_choice = input("Enter your choice (a/b): ")
            if sub_choice == "a":
                # Read files on the system (LFI testing)
                urls_file = input("Enter the file containing URLs with GET parameters (e.g., Fuzz_GETResults.txt): ")
                lfi_wordlist_file = input("Enter the LFI wordlist file path (e.g., LFI-Jhaddix.txt): ")
                concurrency = int(input("Enter the number of concurrent workers: "))
                # Ask if the user wants to specify cookies
                use_cookies = input("Do you want to specify cookies? (y/n): ").lower()
                cookies = {}
                if use_cookies == "y":
                    cookie_input = input("Enter cookies in key=value format (e.g., PHPSESSID=abc123; security=low): ")
                    try:
                        # Parse cookies into a dictionary
                        cookies = dict(cookie.split("=") for cookie in cookie_input.split("; "))
                    except ValueError:
                        print("[-] Invalid cookie format. Please use 'key=value' pairs separated by ';'.")
                        cookies = {}
                await test_lfi(urls_file, lfi_wordlist_file, concurrency, cookies)
            elif sub_choice == "b":
                # Read source code of a webpage using PHP filter
                try:
                    # Read the URL from Fuzz_GETResults.txt
                    with open("Fuzz_GETResults.txt", "r") as file:
                        url = file.readline().strip()

                    if not url:
                        print("[-] The Fuzz_GETResults.txt file is empty or does not contain a valid URL.")
                        continue

                    print(f"[+] Using URL from Fuzz_GETResults.txt: {url}")

                    # Ask if the user wants to specify cookies
                    use_cookies = input("Do you want to specify cookies? (y/n): ").lower()
                    cookies = {}
                    if use_cookies == "y":
                        cookie_input = input(
                            "Enter cookies in key=value format (e.g., PHPSESSID=abc123; security=low): ")
                        try:
                            # Parse cookies into a dictionary
                            cookies = dict(cookie.strip().split("=") for cookie in cookie_input.split(";"))
                        except ValueError:
                            print("[-] Invalid cookie format. Please use 'key=value' pairs separated by ';'.")
                            cookies = {}

                    # Call the fetch_webpage_source function with cookies
                    await fetch_webpage_source(url, cookies)
                except FileNotFoundError:
                    print("[-] Fuzz_GETResults.txt not found. Please ensure the file exists in the current directory.")

        elif choice == "3":
            # RCE
            print("\n=== RCE Options ===")
            print("a. expect")
            print("b. GET request")
            print("c. POST request")
            print("d. Log session poisoning")
            sub_choice = input("Enter your choice (a-d): ")
            if sub_choice == "a":
                # Call the RCE expect functionality
                await rce_expect()

            elif sub_choice == "b":
                # Call the RCE data:// wrapper functionality
                await rce_data()

            elif sub_choice == "c":
                # Call the RCE POST request functionality
                await rce_post()

            elif sub_choice == "d":
                # Call the RCE log poisoning functionality
                await rce_log_poisoning()

            else:
                print("[+] Other RCE features not implemented yet.")

        elif choice == "4":
            # RFI
            await rfi_main()
        elif choice == "5":
            print("[+] Exiting...")
            break
        else:
            print("[-] Invalid choice. Please try again.")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except RuntimeError:
        print("[-] Error: An event loop is already running. Try running outside interactive environments like Jupyter Notebook.")